﻿namespace ConsoleApp_MnTDefferDyNr
{
    public class DayTemp
    {
    }
}